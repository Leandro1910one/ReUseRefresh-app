
package com.reuserefresh.app

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF10131A)
private val Panel = Color(0xFF1B2230)
private val Accent = Color(0xFF37C6A4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ReUseRefreshApp() }
    }
}

data class InstalledApp(
    val name: String,
    val packageName: String
)

@Composable
fun ReUseRefreshApp() {
    var selected by remember { mutableStateOf("Início") }

    val sections = listOf(
        "Início", "Aplicativos", "Configurações", "Licença"
    )

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Ink,
            surface = Panel,
            primary = Accent
        )
    ) {
        Row(
            Modifier
                .fillMaxSize()
                .background(Ink)
                .padding(22.dp)
        ) {
            Column(
                Modifier.width(190.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("ReUse", fontSize = 30.sp, color = Color.White)
                Text("REFRESH", fontSize = 13.sp, color = Accent)

                Spacer(Modifier.height(18.dp))

                sections.forEach { item ->
                    Button(
                        onClick = { selected = item },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor =
                                if (selected == item) Accent else Panel,
                            contentColor = Color.White
                        )
                    ) {
                        Text(item)
                    }
                }
            }

            Spacer(Modifier.width(28.dp))

            Column(Modifier.fillMaxSize()) {
                Text(
                    selected,
                    fontSize = 27.sp,
                    color = Color.White
                )

                Spacer(Modifier.height(18.dp))

                when (selected) {
                    "Início" -> {
                        Text(
                            "Seu ambiente Android, organizado em um só lugar.",
                            color = Color.LightGray,
                            fontSize = 17.sp
                        )
                        Spacer(Modifier.height(22.dp))
                        Text(
                            "ReUse Refresh • versão 0.2.0",
                            color = Accent
                        )
                    }

                    "Aplicativos" -> AppCatalog()

                    "Configurações" -> Text(
                        "Configurações do dispositivo serão implementadas nesta etapa.",
                        color = Color.LightGray
                    )

                    "Licença" -> Text(
                        "Licenciamento próprio: módulo ainda não conectado ao servidor.",
                        color = Color.LightGray
                    )
                }
            }
        }
    }
}

@Composable
private fun AppCatalog() {
    val context = LocalContext.current
    val packageManager = context.packageManager

    var search by remember { mutableStateOf("") }

    val apps = remember {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        packageManager.queryIntentActivities(intent, 0)
            .mapNotNull { result ->
                val activityInfo = result.activityInfo
                if (activityInfo.packageName == context.packageName) {
                    null
                } else {
                    InstalledApp(
                        name = result.loadLabel(packageManager).toString(),
                        packageName = activityInfo.packageName
                    )
                }
            }
            .distinctBy { it.packageName }
            .sortedBy { it.name.lowercase() }
    }

    val filteredApps = apps.filter {
        it.name.contains(search, ignoreCase = true)
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            label = { Text("Pesquisar aplicativo") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(Modifier.height(14.dp))

        Text(
            "${filteredApps.size} aplicativos encontrados",
            color = Accent
        )

        Spacer(Modifier.height(12.dp))

        if (filteredApps.isEmpty()) {
            Text(
                "Nenhum aplicativo encontrado.",
                color = Color.LightGray
            )
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 170.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredApps, key = { it.packageName }) { app ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Panel
                        ),
                        onClick = {
                            val launchIntent =
                                packageManager.getLaunchIntentForPackage(
                                    app.packageName
                                )

                            if (launchIntent != null) {
                                try {
                                    context.startActivity(launchIntent)
                                } catch (_: Exception) {
                                }
                            }
                        }
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(90.dp)
                                .padding(14.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                app.name,
                                color = Color.White,
                                fontSize = 17.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
