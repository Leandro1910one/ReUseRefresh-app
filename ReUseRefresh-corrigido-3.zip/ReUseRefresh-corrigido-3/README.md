# ReUse Refresh — projeto inicial

Este repositório contém um esqueleto inicial Android em Kotlin + Jetpack Compose.

## O que já existe
- Aplicativo Android com nome ReUse Refresh.
- Tela inicial escura com navegação lateral.
- Seções iniciais: Início, Aplicativos, Configurações e Licença.
- Manifesto preparado para aparecer no launcher Android e no launcher Android TV.
- Workflow GitHub Actions para compilar um APK de depuração em nuvem.

## Como compilar usando apenas iPhone
1. Extraia este ZIP no app Arquivos.
2. Crie um repositório no GitHub pelo Safari.
3. Envie os arquivos e pastas deste projeto para o repositório.
4. Abra a aba Actions e execute "Build ReUse Refresh APK" (ou aguarde o build após o push).
5. Abra a execução concluída e baixe o artefato `ReUse-Refresh-debug`.
6. Para instalar o APK, transfira-o para um dispositivo Android. iPhone não instala APK.

## Limitações desta versão
Esta é somente a base inicial da interface. Ainda não implementa virtualização de aplicativos,
catálogo real, autenticação, servidor de licenças ou compatibilidade garantida com apps de terceiros.
O projeto deverá ser testado em TV Box e Google TV reais.

## Segurança
O licenciamento será implementado como sistema independente, sem remover ou contornar
as verificações de licença do aplicativo original.
